---
title: 'Textmate Editor App macOS'
layout: post
media_order: textmate.png
date: '19:08 19-11-2018'
image: textmate.jpg
taxonomy:
    category:
        - softwareempfehlungen
    tag:
        - software
        - empfehlung
        - textmate
        - macos
---

Da ich hin und wieder mal auf meine [Lieblingssoftware]() hinweise, sollte auch ein Editor nicht fehlen. Es gibt Editoren für macOS wie Sand am Meer, viele schwören sogar auf spezielle Varianten im Terminal, aber ich, ich habe mich irgendwann für **Textmate** entschieden.


![Textmate auf macOS 10.13](/assets/2018/textmate.png)
<figcaption>Textmate auf macOS 10.13</figcaption>

<!--more-->

Textmate kann alles, was andere Editoren auch können. Und gemeinsam mit Cyberduck, einer freien FTP-Cliennt Variante die es schon gefühlte tausend Jahre gibt, fungiert er bei Doppelklick direkt als gepipter Editor für die Datei auf dem FTP-Server. Super praktisch. Aber das sind nur Kleinigkeiten. Überzeugt euch am besten selbst.

### Ressourcen
- [Download Link](https://macromates.com)